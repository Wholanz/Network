#include <iostream>
#include <windows.h>
#include <Winsock.h>//version 1.1
#include <string>
#include <sstream>
#include <fstream>

#pragma comment(lib,"ws2_32.lib")
const int PORT=6001;

const int PDU_LEN=256;